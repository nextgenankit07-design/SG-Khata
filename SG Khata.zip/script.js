"use strict";

const DB_NAME = "SGKhataDB";
const DB_VERSION = 1;
let db;
let sales = [];
let customers = [];
let products = [];
let settings = { theme: "dark", card: "glass" };

const $ = id => document.getElementById(id);
const money = n => "₹" + Number(n || 0).toLocaleString("en-IN", {
  maximumFractionDigits: 2
});
const today = () => new Date().toISOString().slice(0, 10);
const uid = () => crypto.randomUUID ? crypto.randomUUID() :
  Date.now() + "-" + Math.random().toString(36).slice(2);

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const database = request.result;
      ["sales", "customers", "products", "settings"].forEach(name => {
        if (!database.objectStoreNames.contains(name)) {
          database.createObjectStore(name, { keyPath: "id" });
        }
      });
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getAll(store) {
  return new Promise((resolve, reject) => {
    const request = db.transaction(store, "readonly")
      .objectStore(store).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

function put(store, item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function remove(store, id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2500);
}

function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));

  $(page).classList.add("active");
  const nav = document.querySelector(`[data-page="${page}"]`);
  if (nav) nav.classList.add("active");

  if (page === "home") renderHome();
  if (page === "history") renderHistory();
  if (page === "reports") renderReports();
  if (page === "customers") renderCustomers();
  if (page === "products") renderProducts();
  if (page === "settings") applySettings();
}

function dateValue(value) {
  return new Date(value);
}

function total(s) {
  return Number(s.qty) * Number(s.price);
}

function renderHome() {
  const now = new Date();
  const list = sales.filter(s => {
    const d = dateValue(s.date);
    return !isNaN(d);
  });

  const daily = list.filter(s => s.date.slice(0, 10) === today());
  const monthly = list.filter(s => {
    const d = dateValue(s.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const yearly = list.filter(s => dateValue(s.date).getFullYear() === now.getFullYear());

  $("todaySales").textContent = money(daily.reduce((a, s) => a + total(s), 0));
  $("todayTransactions").textContent = daily.length + " transactions";
  $("monthSales").textContent = money(monthly.reduce((a, s) => a + total(s), 0));
  $("yearSales").textContent = money(yearly.reduce((a, s) => a + total(s), 0));
  $("itemsSold").textContent = list.reduce((a, s) => a + Number(s.qty), 0);
  $("totalTransactions").textContent = list.length;

  const recent = [...list].sort((a, b) => dateValue(b.date) - dateValue(a.date)).slice(0, 5);
  $("recentSales").innerHTML = recent.length ? recent.map(saleHTML).join("") :
    '<div class="empty-state">No sales recorded yet.</div>';
}

function saleHTML(s) {
  return `<div class="sale-item">
    <div><div class="item-name">${escapeHTML(s.product)}</div>
    <div class="item-sub">${escapeHTML(s.date.replace("T", " "))} · ${escapeHTML(s.payment)}</div>
    <div class="item-sub">Qty: ${s.qty}</div></div>
    <div class="item-amount">${money(total(s))}</div>
  </div>`;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);
}

function previewTotal() {
  const qty = Number($("saleQty").value || 0);
  const price = Number($("salePrice").value || 0);
  $("saleTotal").textContent = money(qty * price);
}

$("saleQty").addEventListener("input", previewTotal);
$("salePrice").addEventListener("input", previewTotal);

$("saleForm").addEventListener("submit", async e => {
  e.preventDefault();

  const product = $("saleProduct").value.trim();
  const qty = Number($("saleQty").value);
  const price = Number($("salePrice").value);
  const date = $("saleDate").value;

  if (!product || !Number.isInteger(qty) || qty < 1 ||
      !Number.isFinite(price) || price < 0 || !date) {
    showToast("Please check sale details.");
    return;
  }

  const sale = {
    id: uid(), product, qty, price,
    payment: $("salePayment").value,
    date, createdAt: new Date().toISOString()
  };

  try {
    await put("sales", sale);
    sales.push(sale);
    $("saleForm").reset();
    $("saleQty").value = 1;
    $("saleDate").value = currentDateTime();
    previewTotal();
    showToast("Sale saved successfully!");
    showPage("home");
  } catch (err) {
    showToast("Could not save sale.");
  }
});

function currentDateTime() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function renderHistory() {
  const q = $("historySearch").value.toLowerCase();
  const day = $("historyDate").value;

  const filtered = [...sales]
    .filter(s => s.product.toLowerCase().includes(q))
    .filter(s => !day || s.date.slice(0, 10) === day)
    .sort((a, b) => dateValue(b.date) - dateValue(a.date));

  $("historyList").innerHTML = filtered.length ? filtered.map(s =>
    `<div class="sale-item">
      <div><div class="item-name">${escapeHTML(s.product)}</div>
      <div class="item-sub">${escapeHTML(s.date.replace("T", " "))} · ${escapeHTML(s.payment)}</div>
      <div class="item-sub">Qty ${s.qty} × ${money(s.price)}</div>
      <div class="item-sub">
        <button class="text-btn" onclick="editSale('${s.id}')">Edit</button>
        <button class="text-btn" onclick="deleteSale('${s.id}')">Delete</button>
      </div></div>
      <div class="item-amount">${money(total(s))}</div>
    </div>`).join("") :
    '<div class="empty-state">No matching sales found.</div>';
}

$("historySearch").addEventListener("input", renderHistory);
$("historyDate").addEventListener("change", renderHistory);

function clearHistoryFilter() {
  $("historySearch").value = "";
  $("historyDate").value = "";
  renderHistory();
}

async function editSale(id) {
  const s = sales.find(x => x.id === id);
  if (!s) return;

  const product = prompt("Product name:", s.product);
  if (product === null) return;
  const qty = Number(prompt("Quantity:", s.qty));
  if (!Number.isInteger(qty) || qty < 1) return showToast("Invalid quantity.");
  const price = Number(prompt("Price:", s.price));
  if (!Number.isFinite(price) || price < 0) return showToast("Invalid price.");

  const updated = { ...s, product: product.trim(), qty, price };
  await put("sales", updated);
  sales = sales.map(x => x.id === id ? updated : x);
  renderHistory();
  renderHome();
  showToast("Sale updated.");
}

async function deleteSale(id) {
  if (!confirm("Delete this sale permanently?")) return;
  await remove("sales", id);
  sales = sales.filter(s => s.id !== id);
  renderHistory();
  renderHome();
  showToast("Sale deleted.");
}

function renderReports() {
  const years = [...new Set([
    new Date().getFullYear(),
    ...sales.map(s => dateValue(s.date).getFullYear())
  ])].sort((a, b) => b - a);

  const select = $("reportYear");
  const previous = Number(select.value);
  select.innerHTML = years.map(y => `<option value="${y}">${y}</option>`).join("");
  if (years.includes(previous)) select.value = previous;

  const year = Number(select.value || new Date().getFullYear());
  const data = sales.filter(s => dateValue(s.date).getFullYear() === year);

  $("reportRevenue").textContent = money(data.reduce((a, s) => a + total(s), 0));
  $("reportTransactions").textContent = data.length;
  $("reportItems").textContent = data.reduce((a, s) => a + Number(s.qty), 0);

  const names = ["January","February","March","April","May","June",
    "July","August","September","October","November","December"];

  $("monthlyBreakdown").innerHTML = names.map((name, month) => {
    const rows = data.filter(s => dateValue(s.date).getMonth() === month);
    const amount = rows.reduce((a, s) => a + total(s), 0);
    return `<div class="sale-item">
      <div><div class="item-name">${name}</div>
      <div class="item-sub">${rows.length} transactions</div></div>
      <div class="item-amount">${money(amount)}</div>
    </div>`;
  }).join("");
}

$("reportYear").addEventListener("change", renderReports);

function renderCustomers() {
  $("customerList").innerHTML = customers.length ? customers.map(c =>
    `<div class="customer-item">
      <div><div class="item-name">${escapeHTML(c.name)}</div>
      <div class="item-sub">${escapeHTML(c.phone || "No phone")}</div></div>
      <div><div class="item-amount">${money(c.balance)}</div>
      <button class="text-btn" onclick="customerPayment('${c.id}')">Payment</button>
      <button class="text-btn" onclick="deleteCustomer('${c.id}')">Delete</button></div>
    </div>`).join("") : '<div class="empty-state">No customers added.</div>';
}

$("customerForm").addEventListener("submit", async e => {
  e.preventDefault();
  const c = {
    id: uid(),
    name: $("customerName").value.trim(),
    phone: $("customerPhone").value.trim(),
    balance: Number($("customerBalance").value || 0)
  };
  await put("customers", c);
  customers.push(c);
  $("customerForm").reset();
  $("customerBalance").value = 0;
  renderCustomers();
  showToast("Customer added.");
});

async function customerPayment(id) {
  const c = customers.find(x => x.id === id);
  if (!c) return;
  const amount = Number(prompt("Enter amount received (₹):", "0"));
  if (!Number.isFinite(amount) || amount <= 0) return showToast("Invalid amount.");
  if (amount > c.balance) return showToast("Amount exceeds balance.");
  c.balance -= amount;
  await put("customers", c);
  renderCustomers();
  showToast("Payment recorded.");
}

async function deleteCustomer(id) {
  if (!confirm("Delete this customer?")) return;
  await remove("customers", id);
  customers = customers.filter(c => c.id !== id);
  renderCustomers();
  showToast("Customer deleted.");
}

function renderProducts() {
  $("productList").innerHTML = products.length ? products.map(p =>
    `<div class="product-item">
      <div><div class="item-name">${escapeHTML(p.name)}</div>
      <div class="item-sub">Catalogue item</div></div>
      <div><div class="item-amount">${money(p.price)}</div>
      <button class="text-btn" onclick="deleteProduct('${p.id}')">Delete</button></div>
    </div>`).join("") : '<div class="empty-state">No products added.</div>';

  $("productOptions").innerHTML = products.map(p =>
    `<option value="${escapeHTML(p.name)}"></option>`).join("");
}

$("productForm").addEventListener("submit", async e => {
  e.preventDefault();
  const p = {
    id: uid(),
    name: $("productName").value.trim(),
    price: Number($("productPrice").value)
  };
  await put("products", p);
  products.push(p);
  $("productForm").reset();
  renderProducts();
  showToast("Product saved.");
});

async function deleteProduct(id) {
  if (!confirm("Delete this product?")) return;
  await remove("products", id);
  products = products.filter(p => p.id !== id);
  renderProducts();
  showToast("Product deleted.");
}

function applySettings() {
  $("themeSelect").value = settings.theme;
  $("cardSelect").value = settings.card;
  document.body.classList.toggle("light", settings.theme === "light");
  document.body.classList.remove("card-glass", "card-edge", "card-none");
  document.body.classList.add("card-" + settings.card);
}

async function saveSettings() {
  settings.theme = $("themeSelect").value;
  settings.card = $("cardSelect").value;
  await put("settings", { id: "appearance", ...settings });
  applySettings();
  showToast("Appearance saved.");
}

$("themeSelect").addEventListener("change", saveSettings);
$("cardSelect").addEventListener("change", saveSettings);

function downloadFile(name, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function exportBackup() {
  const backup = {
    app: "SG Khata",
    version: 1,
    exportedAt: new Date().toISOString(),
    sales, customers, products, settings
  };
  downloadFile(
    `SG-Khata-Backup-${today()}.json`,
    JSON.stringify(backup, null, 2),
    "application/json"
  );
  showToast("Backup downloaded.");
}

$("backupFile").addEventListener("change", async e => {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const backup = JSON.parse(await file.text());
    if (backup.app !== "SG Khata" ||
        !Array.isArray(backup.sales) ||
        !Array.isArray(backup.customers) ||
        !Array.isArray(backup.products)) {
      throw new Error("Invalid backup");
    }

    if (!confirm("Import backup? Existing records will be kept and duplicate IDs skipped.")) return;

    const merge = (current, incoming, store) => {
      const ids = new Set(current.map(x => x.id));
      return incoming.filter(x => x && x.id && !ids.has(x.id));
    };

    for (const item of merge(sales, backup.sales, "sales")) await put("sales", item);
    for (const item of merge(customers, backup.customers, "customers")) await put("customers", item);
    for (const item of merge(products, backup.products, "products")) await put("products", item);

    sales = await getAll("sales");
    customers = await getAll("customers");
    products = await getAll("products");

    if (backup.settings && typeof backup.settings === "object") {
      settings = { ...settings, ...backup.settings };
      await put("settings", { id: "appearance", ...settings });
    }

    renderHome();
    renderProducts();
    renderCustomers();
    showToast("Backup imported successfully.");
  } catch (err) {
    showToast("Invalid backup file.");
  } finally {
    e.target.value = "";
  }
});

function exportCSV() {
  const rows = [
    ["Date", "Product", "Quantity", "Price", "Total", "Payment"],
    ...sales.map(s => [s.date, s.product, s.qty, s.price, total(s), s.payment])
  ];
  const csv = rows.map(row =>
    row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")
  ).join("\r\n");

  downloadFile("SG-Khata-Sales.csv", "\uFEFF" + csv, "text/csv;charset=utf-8");
  showToast("CSV downloaded.");
}

function printReport() {
  const w = window.open("", "_blank");
  if (!w) return showToast("Allow popups to print PDF.");
  const rows = [...sales].sort((a,b) => dateValue(b.date) - dateValue(a.date));
  w.document.write(`<html><head><title>SG Khata Report</title>
  <style>body{font-family:Arial;padding:25px}table{width:100%;border-collapse:collapse}
  th,td{padding:9px;border:1px solid #ddd;text-align:left}</style></head><body>
  <h1>Shyam Garments - Sales Report</h1>
  <p>Generated: ${new Date().toLocaleString("en-IN")}</p>
  <table><tr><th>Date</th><th>Product</th><th>Qty</th><th>Price</th><th>Total</th><th>Payment</th></tr>
  ${rows.map(s => `<tr><td>${escapeHTML(s.date)}</td><td>${escapeHTML(s.product)}</td>
  <td>${s.qty}</td><td>${money(s.price)}</td><td>${money(total(s))}</td>
  <td>${escapeHTML(s.payment)}</td></tr>`).join("")}
  </table></body></html>`);
  w.document.close();
  w.print();
}

async function init() {
  try {
    db = await openDB();
    [sales, customers, products] = await Promise.all([
      getAll("sales"), getAll("customers"), getAll("products")
    ]);

    const savedSettings = await getAll("settings");
    const appearance = savedSettings.find(x => x.id === "appearance");
    if (appearance) settings = { theme: appearance.theme || "dark", card: appearance.card || "glass" };

    $("saleDate").value = currentDateTime();
    applySettings();
    renderHome();
    renderProducts();
    renderCustomers();
    renderReports();
    previewTotal();
  } catch (err) {
    alert("Local database could not be opened. Please open this app in a browser that supports IndexedDB.");
  }
}

init();